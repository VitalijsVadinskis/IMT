import React from 'react';
import { Text, View } from 'react-native';

const HelloWorldApp = () => {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
      }}>
      <Text>Hello World from Group group Nr.14 Vitalijs Vadinskis!  </Text>
      <Text>This is my Vitalijs Vadinskis first React Native application!</Text>
    </View>
  )
}
export default HelloWorldApp;